import React from 'react'
import './common.css'

// loading overlay
export default function Loading(){
    return <div className="overlay">
            <div className="loading">
    </div>
        </div>
}