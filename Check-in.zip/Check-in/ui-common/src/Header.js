import React from 'react'
import './common.css'

export default function Header() {
    return (
        <div className="header">
            
            <h2>Banking to Bank @NWM-Visionaries</h2>
        </div>
    )
}