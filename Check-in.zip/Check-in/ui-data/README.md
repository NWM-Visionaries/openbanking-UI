# `ui-data`

> Service and redux interation package
