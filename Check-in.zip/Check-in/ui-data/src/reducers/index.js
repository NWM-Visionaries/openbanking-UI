import app from './appReducer'
import auth from './authReducer'
import common from './commonReducer'
import account from './accountReducer'

export default {
    app,
    auth,
    common,
    account,
}
