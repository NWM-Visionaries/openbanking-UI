export const SET_LOADING = 'SET_LOADING'
export const SET_ERROR = 'SET_ERROR'