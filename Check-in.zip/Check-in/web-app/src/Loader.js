import React from 'react'
import { Redirect } from 'react-router'

export default function Loader() {
    // mock component 
    return <Redirect to="/redirecting#code=Njugff123Ahejkf8hbkkjjh" />
}
